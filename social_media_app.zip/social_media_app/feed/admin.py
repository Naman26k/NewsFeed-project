from django.contrib import admin
#from .models import UserProfile, Message
# Register your models here.
from .models import Post,Comment,Message

#admin.site.register(UserProfile)
#admin.site.register(Message)
admin.site.register(Comment)
admin.site.register(Post)