from django import forms
from .models import Message,Post, Comment

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['content']  # Add other fields as needed
        widgets = {
            'content': forms.Textarea(attrs={'rows': 4, 'cols': 50}),
            # Add widgets for other fields if necessary
        }

class MessageForm(forms.ModelForm):
    class Meta:
        model = Message
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={'rows': 3, 'cols': 40}),
        }

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content', 'post']
