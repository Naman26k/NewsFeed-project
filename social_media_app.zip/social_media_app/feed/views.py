from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .forms import MessageForm, CommentForm,PostForm
from django.http import JsonResponse
from .models import Message, MessageLike, Comment, CommentLike,Post,PostLike
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Log in the user after successful registration
            return redirect('/feed')  # Redirect to the feed after registration
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})


def feed(request):
    # Get all posts including the newly added posts
    posts = Post.objects.all().order_by('-created_at')  # Fetch posts in descending order by creation time

    # Get posts added by the current user
    user_posts = Post.objects.filter(user=request.user)

    return render(request, 'feed.html', {'posts': posts, 'user_posts': user_posts})

def feed_view(request):
    # Retrieve all messages from the database
    messages = Message.objects.all().order_by('-created_at')  

    return render(request, 'feed.html', {'messages': messages})

def message_detail_view(request, message_id):
    # Retrieve a specific message using its ID
    message = get_object_or_404(Message, pk=message_id)  

    return render(request, 'message_detail.html', {'message': message})



def view_posts(request):
    posts = Post.objects.all()  # Fetch all posts from the database
    return render(request, 'view_posts.html', {'posts': posts})


@login_required
def add_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            new_post = form.save(commit=False)
            new_post.user = request.user
            new_post.save()
            return redirect('feed')  # Replace 'feed' with the appropriate URL name
    else:
        form = PostForm()
    return render(request, 'add_post.html', {'form': form})  # Create a corresponding template




@login_required
def add_comment(request, post_id):
    post = Post.objects.get(pk=post_id)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            new_comment = form.save(commit=False)
            new_comment.user = request.user
            new_comment.post = post  # Link the comment to the associated post
            new_comment.save()
            return redirect('view_posts')  # Redirect back to view_posts page
    else:
        form = CommentForm()
    return render(request, 'add_comment.html', {'form': form})

@login_required
def like_post(request, post_id):
    post = Post.objects.get(pk=post_id)
    like, created = PostLike.objects.get_or_create(user=request.user, post=post)

    if not created:
        like.delete()

    return redirect('view_posts')  # Redirect back to view_posts page


@login_required
def create_message(request):
    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            new_message = form.save(commit=False)
            new_message.user = request.user
            new_message.save()
            return redirect('feed')
    else:
        form = MessageForm()
    return render(request, 'create_message.html', {'form': form})

@login_required
def update_message(request, message_id):
    message = get_object_or_404(Message, pk=message_id)
    if request.user == message.user:
        if request.method == 'POST':
            form = MessageForm(request.POST, instance=message)
            if form.is_valid():
                form.save()
                return redirect('feed')
        else:
            form = MessageForm(instance=message)
        return render(request, 'update_message.html', {'form': form})
    else:
        return render(request, 'error.html', {'error_message': 'You are not allowed to update this message.'})

@login_required
def delete_message(request, message_id):
    message = get_object_or_404(Message, pk=message_id)
    if request.user == message.user:
        message.delete()
        return redirect('feed')
    else:
        return render(request, 'error.html', {'error_message': 'You are not allowed to delete this message.'})
    
def like_message(request, message_id):
    message = get_object_or_404(Message, pk=message_id)
    like, created = MessageLike.objects.get_or_create(user=request.user, message=message)

    if not created:
        like.delete()

    return JsonResponse({'liked': created})

def like_comment(request, comment_id):
    comment = get_object_or_404(Comment, pk=comment_id)
    like, created = CommentLike.objects.get_or_create(user=request.user, comment=comment)

    if not created:
        like.delete()

    return JsonResponse({'liked': created})



@login_required
def delete_post(request, post_id):
    post = get_object_or_404(Post, pk=post_id)

    # Check if the logged-in user is the owner of the post
    if post.user == request.user:
        post.delete()  # Delete the post if the user owns it
        # Redirect to the feed or another appropriate page after deletion
        return redirect('view_posts')
    else:
        # Handle the case where the logged-in user is not the owner of the post
        # For instance, display an error or redirect to another page
        return render(request, 'error.html', {'message': 'You are not authorized to delete this post.'})
    
@login_required
def delete_comment(request, comment_id):
    comment = get_object_or_404(Comment, pk=comment_id)

    if comment.user == request.user:
        post_id = comment.post.id  # Get the ID of the post before deleting the comment
        comment.delete()
        # Redirect to the 'view_posts' URL pattern with the correct post_id
        return redirect('view_posts', post_id=post_id)
    else:
        return render(request, 'error.html', {'message': 'You are not authorized to delete this comment.'})