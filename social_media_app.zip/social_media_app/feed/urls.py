from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('feed/', views.feed_view, name='feed'),
    path('add_post/', views.add_post, name='add_post'),
    path('view_posts/', views.view_posts, name='view_posts'),

    path('message/<int:message_id>/', views.message_detail_view, name='message_detail'),
     path('like/message/<int:message_id>/', views.like_message, name='like_message'),
    path('like/comment/<int:comment_id>/', views.like_comment, name='like_comment'),
    
    path('add_comment/<int:post_id>/', views.add_comment, name='add_comment'),
    path('like_post/<int:post_id>/', views.like_post, name='like_post'),
     path('delete_post/<int:post_id>/', views.delete_post, name='delete_post'),

   path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
     path('delete_comment/<int:comment_id>/', views.delete_comment, name='delete_comment'),


]